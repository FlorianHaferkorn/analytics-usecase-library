---
id: XD-002
factsheet_type: business
---

# XD-002 - Resource Utilization  

## Business Factsheet

---

## 0. Metadata (Mandatory)

- **Use Case ID:** XD-002
- **Domain:** Experience / Service
- **Business Owner:** Head of Customer Service / Workforce Management
- **KPI Owner:** Service Operations / Workforce Planning
- **Decision Owner:** CX/Service Leadership
- **Reporting Level:** Tactical / Operational
- **Analytics Stage:** Diagnostic / Prescriptive
- **Related Data Contract:** core/data_contracts/domains/experience.yaml
- **Related Semantic Model:** Framework: core/strategy_operating_model/operating_model/semantic_layer.md. Aurora: showcases/aurora_group/semantic_models/Experience.SemanticModel (domain model for XD-*).

---

## 1. Business Summary

**Purpose:** Optimize resource utilization and occupancy while protecting SLA and
customer experience.  
**Business Value:** Better staffing efficiency, reduced overtime/shrinkage costs,
and controlled backlog without SLA degradation.  
**Out of Scope:** Detailed SLA performance drivers (XD-001); sales pipeline; field
service dispatching.

---

## 2. Core Business Questions

- What are utilization and occupancy by channel/queue/region vs targets?
- How do overtime and shrinkage affect SLA attainment and backlog?
- Where do staffing imbalances create SLA risk or idle capacity?
- Which actions improve utilization without harming quality?

**Example Query Patterns (optional):**

- "Which queues have utilization below target and SLA/backlog risk?"
- "Where is overtime rising while shrinkage is high?"

---

### 3. KPI & Action Code Overview

| KPI ID | Role |
|--------|------|
| res.utilization.pct | Strategic |
| res.occupancy.pct | Influencing |
| svc.sla.attainment.pct | Influencing |
| res.overtime.pct | Influencing |
| res.shrinkage.pct | Influencing |
| svc.backlog.count | Influencing |
| svc.tickets.created.count | Influencing |

**Action Codes:** X-R2.1, X-R2.2, X-R2.3, X-R2.4

> Full machine-readable configuration in `UseCase_Bracket.yaml` (SSOT).

---

## 4. Action Codes (Summary)

Structured summary of action codes (definitions remain in YAML).


> Machine-readable KPI + Action configuration has been extracted to `UseCase_Bracket.yaml` (SSOT).
> This factsheet focuses on business context only.


---

## 5. 3-30-300 Page Layout (Mandatory)

### 5.1 3-Second Layer (KPI Cards)

- Utilization %  
- Occupancy %  
- Overtime %  
- Shrinkage %  
- SLA % / Backlog Count  

### 5.2 30-Second Layer (Main Visuals)

- **Utilization vs Band by Queue**
  - Visual Type: Column
  - X-Axis: dim_org[Queue]
  - Y-Axis: [Utilization %], Band
  - Segment: Channel/Region
  - Default Filter: Current month
  - Notes: Core ranking

- **Occupancy vs Band**
  - Visual Type: Column
  - X-Axis: dim_org[Queue]
  - Y-Axis: [Occupancy %], Band
  - Segment: Channel/Region
  - Default Filter: Current month
  - Notes: Balance view

- **Overtime & Shrinkage Trend**
  - Visual Type: Line
  - X-Axis: dim_date[Week]
  - Y-Axis: [Overtime %], [Shrinkage %]
  - Segment: Region/Channel
  - Default Filter: L12W
  - Notes: Capacity health

- **SLA vs Backlog**
  - Visual Type: Scatter
  - X-Axis: [SLA %]
  - Y-Axis: [Backlog Count]
  - Segment: Queue/Region
  - Default Filter: Current quarter
  - Notes: Service risk

### 5.3 Required Slicers (Mandatory)

- Date (Week/Month)  
- Region / Channel / Queue  
- Agent Group / Skill (if available)  

---

### 5.4 300-Second Layer (Diagnostics)

- Queue- and agent-group-level workforce table with utilization, occupancy, overtime, shrinkage, and SLA context.
- Capacity imbalance view that separates demand surge from structural shrinkage or routing problems.
- Action panel routing for utilization orchestration, capacity reallocation, shrinkage control, or overtime containment.

## 6. Data Requirements Summary

- Required facts: workforce-management time records plus support-case volume and backlog context.
- Required dimensions: date, organization, queue, and agent-group attributes where available.
- Required grain: agent_day with queue/day roll-up for trend and balancing views.
- Required time range: 12 to 24 months history.
- Required slicers: Date, Region/Channel/Queue, Agent Group or Skill.

---

## 7. Dependencies, Assumptions & Constraints

- WFM data includes work/idle/wrap, overtime, shrinkage; SLA/backlog
  available from cases.
- Target bands defined for utilization/occupancy; exclusions for
  training/ramp-up.
- OneLake canonical dims used (dim_date, dim_org, security_user_org).
- Data latency =24h.

---

## 8. Success Criteria

- Impact: Utilization/occupancy within bands; overtime/shrinkage reduced; SLA
  stable/improved; backlog controlled.  
- Adoption: Used in weekly WFM/service ops reviews; action codes triggered with
  <5% false positives.  
- Quality: KPI definitions consistent across XD-001/002; reconciled to source
  totals.  
- Decision Frequency: Weekly and daily staffing reviews.

---

## 9. Risks & Wrong Interpretations (Short)

- Overdriving utilization causing quality decline.  
- Misclassifying shrinkage leading to wrong capacity view.  
- Ignoring seasonality causing false alarms on utilization/occupancy.  



## 10. Typical Decision Scenarios

These scenarios illustrate how this use case drives decisions in practice. They are examples — not exhaustive.

### Scenario A: Low Utilization Despite High Demand

**Situation:** Resource utilization is 62% against a 78% target, yet ticket backlog is growing. Occupancy rate is 71% but shrinkage (training, meetings, system downtime) has increased to 22%.

**Decision question:** Is the utilization gap driven by excessive non-productive time, scheduling inefficiency, or skill mismatch (agents available but not qualified for queued work)?

**Who decides:** Workforce Planning Lead + Operations Manager.

**Consequence of inaction:** Understaffed queues grow while available agents sit in non-productive activities; overtime costs spike to compensate.

**Action Code triggered:** X-R2.1 (Utilization Recovery) — activates shrinkage decomposition and schedule adherence analysis.

### Scenario B: Overtime Spike with Stable Headcount

**Situation:** Overtime rate jumped to 18% (target <8%). Headcount is unchanged, but volume per agent increased 12% due to a product launch. SLA is at risk.

**Decision question:** Is this a temporary surge requiring short-term overtime, or does the volume step-change require permanent capacity adjustment?

**Who decides:** Workforce Planning Lead + Service Director.

**Consequence of inaction:** Sustained overtime degrades agent well-being, increases attrition, and costs 1.5x base rate.

**Action Code triggered:** X-R2.2 (Capacity Adjustment) — activates volume trend analysis and capacity model re-run.
